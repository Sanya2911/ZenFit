document.getElementById("send-button").addEventListener("click", function () {
    var inputValue = document.getElementById("input-field").value;
    if (inputValue.trim() !== "") {
        appendMessage("user", inputValue);
    }
    document.getElementById("input-field").value = "";
});

function appendMessage(sender, message) {
    var chatbox = document.getElementById("chatbox");
    var item = document.createElement("div");
    item.className = sender === "user" ? "item right" : "item";
    item.innerHTML = `
        <div class="icon">
            <i class="fa fa-${sender === "user" ? "user" : "robot"}"></i>
        </div>
        <div class="msg">
            <p>${message}</p>
        </div>
    `;
    chatbox.appendChild(item);
    chatbox.scrollTop = chatbox.scrollHeight; 
}